import assert from "node:assert/strict";

const calls = [];
let child = 0;
globalThis.fetch = async (input, options = {}) => {
  const url = new URL(String(input));
  calls.push({ url, method: options.method });
  if (url.pathname.endsWith("/media") && url.searchParams.get("media_type") === "IMAGE") {
    child += 1;
    return { ok: true, json: async () => ({ id: `child-${child}` }) };
  }
  if (url.pathname.endsWith("/media") && url.searchParams.get("media_type") === "CAROUSEL") {
    return { ok: true, json: async () => ({ id: "parent-1" }) };
  }
  if (url.pathname.endsWith("/media_publish")) {
    return { ok: true, json: async () => ({ id: "instagram-media-1" }) };
  }
  return { ok: true, json: async () => ({ id: url.pathname.split("/").at(-1), status_code: "FINISHED" }) };
};

const { publishCarousel } = await import("./dist/instagram.js");
const result = await publishCarousel(
  { instagramUserId: "ig-user", accessToken: "test-token" },
  ["https://example.com/1.png", "https://example.com/2.png"],
  "approved copy"
);

const childCalls = calls.filter(({ url }) => url.searchParams.get("media_type") === "IMAGE");
assert.equal(childCalls.length, 2);
for (const { url } of childCalls) {
  assert.equal(url.searchParams.get("is_carousel_item"), "true");
  assert.ok(url.searchParams.get("image_url"));
}
const parent = calls.find(({ url }) => url.searchParams.get("media_type") === "CAROUSEL");
assert.equal(parent.url.searchParams.get("children"), "child-1,child-2");
assert.equal(parent.url.searchParams.get("caption"), "approved copy");
assert.equal(result.id, "instagram-media-1");
console.log("carousel request construction: ok");
