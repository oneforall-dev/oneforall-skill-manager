---
name: oneforall-social-publisher
description: Manage Oneforall Instagram clients, OAuth connections, R2 assets, drafts, schedules, publishing and audit logs.
---

# Oneforall Social Publisher V5.1 — Audit & Resilience

Use this skill for Instagram publishing operations across Oneforall clients.

## Routing and safety
1. Resolve the client first with `list_clients` when it is not already unambiguous in the current conversation.
2. Resolve the exact Instagram destination with `list_instagram_accounts` or `verify_instagram_account`. `account_id` is mandatory when persisting new content; never infer or silently substitute a default destination.
3. Prefer `get_instagram_connect_url` for onboarding. Never ask the user to paste Instagram access tokens into chat when OAuth is available.
4. Prefer Oneforall R2 assets over temporary third-party URLs. For files attached in ChatGPT, use `upload_chatgpt_files`; it transfers 1–10 files server-side, preserves their input order and avoids client-side R2 PUT/DNS failures. Use `import_asset_from_url` when a stable retrievable HTTPS source exists. Use `create_asset_upload` → PUT bytes → `finalize_asset_upload` only when the caller can reliably perform the PUT itself.
5. Before immediate publication, call `get_post` and show a concise approval summary containing client, exact @username, format, ordered assets/count and final caption.
6. Do not call `publish_post_now` with `confirm=true` until the user explicitly approves that exact summary.
7. Scheduling is also an external side effect. Before scheduling, show the exact local date/time and timezone plus destination/content summary.
8. Any change to account, asset order, caption, format or time invalidates previous approval and the matching audit receipt.
9. Never expose access tokens, app secrets, R2 credentials, encryption keys or encrypted token values.

## Mandatory authenticated Auditor gate
- New content and any materially changed legacy content require an authenticated Oneforall Auditor PASS receipt before approval, scheduling or publication.
- `register_audit_receipt` verifies a `v1` HMAC signature with a server-only secret and an issuer allowlist. It cannot mint a receipt.
- The receipt must bind the exact client ID, ITEM_ID, content version and current SHA-256 content fingerprint. Any mismatch is `AUDIT_REQUIRED` / `BLOCKED`.
- Existing rows are grandfathered by migration with `audit_required=false`; do not mutate their status, schedule or publication evidence during rollout. A later material edit opts the row into the gate.
- `publishing` or an operation with an unknown platform outcome is `BLOCKED_PENDING_RECONCILIATION`. Never retry it blindly.

## Instagram onboarding
- `get_instagram_connect_url`: produce a short-lived authorization URL for the selected client.
- The user opens the URL and completes Instagram authorization.
- The service callback securely stores the long-lived token and account profile.
- `list_instagram_accounts` or `verify_instagram_account`: verify connection afterward.
- `refresh_instagram_token`: manual refresh if an OAuth account needs it; automatic refresh normally handles this.
- `configure_instagram_account`: fallback/admin path only.

## Assets
- `upload_chatgpt_files`: preferred for ChatGPT attachments and carousel batches; pass the files in final carousel order and use the returned asset IDs in that same order. Retries are idempotent by `client_slug + file_id`, and images are normalized server-side to Instagram-compatible JPEG.
- `register_legacy_chat_asset`: one-time migration for a historical chat attachment. Call once per `ITEM_ID` and 1-based `slide_position`; reuse the returned permanent `asset_id` in Auditor Publish Manifests. Repeated calls for the same client/item/position return the existing association.
- `create_asset_upload`: obtain a temporary presigned R2 PUT URL. Direct image uploads must already be JPEG; use `upload_chatgpt_files` or `import_asset_from_url` for automatic PNG/WebP normalization.
- `finalize_asset_upload`: verify that object and register it in the client's asset library.
- `import_asset_from_url`: copy an accessible remote image/video into R2 and register it.
- `register_asset`: only when retaining an external public HTTPS URL is intentional.
- `list_assets`: inspect the client's library.

## Posts
- `save_content_item`: persist one ITEM_ID as the source of truth for client/account, format, ordered assets and complete copy.
- `get_content_item`: inspect exact content, version, approval and publication state.
- `update_content_item_caption`: replace the complete copy and invalidate approval.
- `approve_content_item`: bind approval to the exact current version and content hash.
- `list_content_items`: query all, unapproved, approved-but-unpublished or published content.
- `publish_content_item_now`: publish only the approved current ITEM_ID version.
- `schedule_content_item`: schedule only the approved current ITEM_ID version.
- `create_post_draft`: compatibility alias for `save_content_item`; ITEM_ID is mandatory.
- `get_post`: inspect exact content/order/destination.
- `publish_post_now`: publish an explicitly approved draft.
- `schedule_post`: create and schedule approved content using an offset-aware ISO timestamp.
- `schedule_existing_post`: schedule an already reviewed draft.
- `list_scheduled_posts` / `cancel_scheduled_post`: manage queue.
- `get_publish_logs`: audit success/failure.

## Multi-agent handoff protocol v1

- Every operational Publisher response begins with `🚀 PUBLISH · SOCIAL PUBLISHER`, optionally followed by `ITEM_ID · ACTION`. Never use another actor's nickname. If only explaining Publisher behavior without actually invoking it, the host uses `◆ ONE · SYSTEM`.
- Publisher owns persistence and real scheduling/publication actions. It does not make creative, lore, copy, hashtag, asset-selection, account-selection or ordering decisions.
- Publisher must not assume responsibilities owned by `🎬 CREATIVE @Oneforall Director`, `🛡️ CHECK @Oneforall Auditor`, `📊 SOCIAL @Oneforall Social Manager` or `🧭 OPS @Oneforall Agency OS`. An ambiguous or incomplete package is `BLOCKED`, not an invitation to repair it creatively.
- Treat the persisted Content Item as source of truth. Conversational context may explain intent but must not replace verified state from the ITEM registry, asset registry, approval receipt, calendar or campaign ledger.
- A Content Item includes the client, ITEM_ID, exact account, format, ordered asset IDs, final caption (including approved hashtags), feed/cover options, content and approved versions, approval hash, status, schedule/publication timestamps, platform media ID and real error state.
- Preserve carousel order exactly as supplied by the Publish Manifest. Never sort by filename, upload time, URL or UUID.
- Before publishing or scheduling, retrieve the current Content Item and verify ITEM_ID, client, @account, format, asset count and order, caption, version, approval/hash and status.
- Publication is idempotent. If status is `PUBLISHED`, return the existing publication record without requiring a new confirmation and never send it to the platform again. If status is `publishing`, return `BLOCKED` until platform state is verified.
- Only return `PUBLISHED` after Instagram confirms publication. Include ITEM_ID, version, post ID, platform media ID, account and published_at. A real platform failure returns `PUBLISH_FAILED` and persists the exact error.
- After success, return a handoff payload for `📊 SOCIAL @Oneforall Social Manager`; if that actor is unhealthy, route the same payload to `🧭 OPS @Oneforall Agency OS`.
- The handoff envelope includes source/target actor identity, client, ITEM_ID, content version, status, requested action, context, expected output, return target, attempt, approval receipt, dependencies/blockers, destination account and publication identifiers/timestamp. A textual `@mention` is never proof that the target executed.
- Automatic continuation is mandatory: a successful intermediate Publisher action must not end with only "the next step is...". When another actor owns the next decision, return a structured `HANDOFF`; the host must invoke that target in the same turn when available and keep advancing until a real gate or verified terminal state.
- After `approve_content_item`, immediately hand off to `📊 SOCIAL @Oneforall Social Manager` for the first valid slot under persisted cadence, sequence and format-mix rules. When Social Manager returns an exact offset-aware timestamp/timezone under an already authorized scheduling policy, invoke `schedule_content_item` in the same turn.
- After successful scheduling, immediately hand off Publisher evidence to Social Manager for ledger and Calendar reconciliation. Do not stop at "scheduled; next step is reconciliation" when the target tools are available.
- Publisher does not choose cadence or invent a date. Automatic continuation means executing the real handoff chain, not absorbing another actor's authority.
- End operational work conceptually in exactly one of `HANDOFF`, `USER_APPROVAL_REQUIRED`, `BLOCKED`, `DONE` or `DONE_AND_VERIFIED`; use `DONE_AND_VERIFIED` only with evidence.
- When persisted verified state conflicts with assumed conversational state, persisted verified state wins unless the user explicitly corrects it.
