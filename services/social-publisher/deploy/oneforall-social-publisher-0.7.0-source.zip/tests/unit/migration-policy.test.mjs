import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

test("audit migration grandfathers existing rows before enabling the default",async()=>{
  const sql=await readFile(new URL("../../migrations/007_audit_receipts_and_publish_operations.sql",import.meta.url),"utf8");
  const grandfather=sql.indexOf("UPDATE posts SET audit_required=false WHERE audit_required IS NULL");
  const defaultTrue=sql.indexOf("ALTER TABLE posts ALTER COLUMN audit_required SET DEFAULT true");
  assert.ok(grandfather>=0);
  assert.ok(defaultTrue>grandfather);
  assert.match(sql,/publish_operations[\s\S]+idempotency_key text NOT NULL UNIQUE/);
  assert.match(sql,/status IN \('claimed','platform_pending','succeeded','failed','unknown'\)/);
});

